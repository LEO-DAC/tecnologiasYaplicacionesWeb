            <!-- End Header -->
            <!-- Begin Page Content -->
            <div class="page-content d-flex align-items-stretch">

                <!-- ################# -->
                <div class="default-sidebar">
                    <!-- Begin Side Navbar -->
                    <nav class="side-navbar box-scroll sidebar-scroll">
                        <!-- Begin Main Navigation -->
                        <ul class="list-unstyled">
													
														<li><router-link to="/proyectos"><i class="ti-blackboard red" style="color: #6574cd"></i><span>Proyectos</span></router-link></li>
                            <li><router-link to="/mistareas"><i class="ion-hammer" style="color: #3490dc"><span>Mis tareas</span></a></router-link></li>
                            <li><a href="#"><i class="ion-cash " style="color: #f6993f"></i><span>Pagos</span></a></li>
                            <li><a href="#"><i class="ion-chatboxes " style="color: #9561e2"></i><span>Tickets</span></a></li>
                            <li><a href="#"><i class="ion-loop" style="color: #6cb2eb"></i><span>Issues</span></a></li>
													
													<li>

															<a  href="{{ route('logout') }}"
																	onclick="event.preventDefault();
																								document.getElementById('logout-form').submit();">


																	<i class="ti-power-off" style="color: #e3342f"></i>
																
																
																
																	<span>
																		{{ __('Cerrar Sesion') }}
																	</span>
															</a>

															<form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
																	@csrf
															</form>


													</li>
													
													
                        </ul>
                        <!-- End Main Navigation -->
                    </nav>
                    <!-- End Side Navbar -->
                </div>
                <!-- End Left Sidebar -->
             </div>
