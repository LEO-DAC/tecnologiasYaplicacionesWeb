
<div class="page-content d-flex align-items-stretch">
    <div class="default-sidebar">
        <nav class="side-navbar box-scroll sidebar-scroll">
            <ul class="list-unstyled">
                
                <li><router-link to="/proyectos"><i class="ti-blackboard red" style="color: #6574cd"></i><span>Proyectos</span></router-link></li>
                <li><a href="#dropdown-forms" aria-expanded="false" data-toggle="collapse"><i class="ion-person-stalker"></i><span>Mis colaboradores</span></a>
                    <ul id="dropdown-forms" class="collapse list-unstyled pt-0">
                        <li><router-link to="/desarrolladores"><span>Desarrolladores</span></router-link></li>
                        <li><a href="#">Clientes</a></li>
                    </ul>
                </li>
                <li><a href="#"><i class="ion-briefcase"></i><span>Empresas</span></a></li>
                <li><a href="#"><i class="ion-cash"></i><span>Pagos</span></a></li>
                <li><a href="#"><i class="ion-chatboxes"></i><span>Tickets</span></a></li>
                <li><a href="#"><i class="ion-loop"></i><span>Issues</span></a></li>
                
                <li>

                    <a  href="{{ route('logout') }}"
                            onclick="event.preventDefault();
                                                        document.getElementById('logout-form').submit();">


                            <i class="ti-power-off" style="color: #e3342f"></i>
                        
                        
                        
                            <span>
                                {{ __('Cerrar Sesion') }}
                            </span>
                    </a>

                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                            @csrf
                    </form>
                </li>
                
            </ul>
        </nav>
    </div>
</div>

