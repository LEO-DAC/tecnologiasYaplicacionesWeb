
            <div class="page-content d-flex align-items-stretch">
                <div class="default-sidebar">
                    <nav class="side-navbar box-scroll sidebar-scroll">
                        <ul class="list-unstyled">
														
                            <li><a href="#"><i class="ion-hammer"></i><span>Mis tareas</span></a></li>
                            <li><a href="#"><i class="ion-cash"></i><span>Mis pagos</span></a></li>
                            <li><a href="#"><i class="ion-chatboxes"></i><span>Mis tickets</span></a></li>
                            
                            <li>
                            <a  href="{{ route('logout') }}"
                                onclick="event.preventDefault();
                                                document.getElementById('logout-form').submit();">
                                <i class="ti-power-off" style="color: #e3342f"></i>
                                <span>
                                    {{ __('Cerrar Sesion') }}
                                </span>
                            </a>
                                <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                    @csrf
                                </form>
                            </li>

                        </ul>
                    </nav>
                </div>
            </div>
        
