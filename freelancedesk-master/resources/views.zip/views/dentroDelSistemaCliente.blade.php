@extends('layouts.principal')
@section('principal')

    <div id="app">

        @include('contenido.customer')
            
            
        <div class="content-inner">
            <div class="container-fluid">
                <router-view></router-view>
                <vue-progress-bar></vue-progress-bar>
            </div>
        </div>	
    </div>

@endsection
