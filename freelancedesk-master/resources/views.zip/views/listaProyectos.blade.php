@extends('layouts.principal')
@section('principal')


<div class="page-content d-flex align-items-stretch">
        <div class="page-content d-flex align-items-stretch">
            <div class="default-sidebar">
                <nav class="side-navbar box-scroll sidebar-scroll">
                    <ul class="list-unstyled">
                                                    
                        <li><a href="#"><i class="ion-hammer active router-link-active"></i><span>Proyectos</span></a></li>

                    </ul>
                </nav>
            </div>
        </div>

        <div class="content-inner mt-5">
            <div class="container-fluid">

                <div id="app">
                    <lista-proyectos tipo-usuario="{{ $tipo }}" > </lista-proyectos>
                </div>


            </div>

            
        </div>
 
    </div>


@endsection