<?php
$user_access[] = [
    'email' => 'bernardo@correo.com',
    'name' => 'Bernardo Granados',
    'country' => 'México',
    'phone' => '12345'

];
$user_access[] = [
    'email' => 'sergio@correo.com',
    'name' => 'Sergio Pineda',
    'country' => 'México',
    'phone' => '67890'

];
$user_access[] = [
    'email' => 'francisco@correo.com',
    'name' => 'Francisco Brito',
    'country' => 'México',
    'phone' => '24680'

];
$user_access[] = [
    'email' => 'francisco@correo.com',
    'name' => 'Francisco Brito',
    'country' => 'México',
    'phone' => '24680'

];
$user_access[] = [
    'email' => 'francisco@correo.com',
    'name' => 'Francisco Brito',
    'country' => 'México',
    'phone' => '24680'

];
$user_access[] = [
    'email' => 'francisco@correo.com',
    'name' => 'Francisco Brito',
    'country' => 'México',
    'phone' => '24680'

];
