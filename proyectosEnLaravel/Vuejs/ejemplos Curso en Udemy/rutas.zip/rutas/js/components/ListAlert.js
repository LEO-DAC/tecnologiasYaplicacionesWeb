Vue.component('list-alert',{
    template:`
    <div class="alert alert-warning" role="alert">
        A simple warning alert—check it out!
    </div>
    `
});