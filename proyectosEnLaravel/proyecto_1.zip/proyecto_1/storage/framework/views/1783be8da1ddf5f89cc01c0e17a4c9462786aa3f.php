<?php $__env->startSection('contenido'); ?>
  <template v-if="menu==0">
 <example-component></example-component>
  </template>

  <template v-if="menu==1">
  <h3>Contenido del menú 1</h3> 
  </template>
  <template v-if="menu==2">
    <h3>Contenido del menú 2</h3> 
  </template>
  <template v-if="menu==3">
    <h3>Contenido del menú 3</h3> 
  </template>
  <template v-if="menu==4">
    <h3>Contenido del menú 4</h3> 
  </template>
  <template v-if="menu==5">
    <h3>Contenido del menú 5</h3> 
  </template>
  <template v-if="menu==6">
    <h3>Contenido del menú </h3> 
  </template>
  <template v-if="menu==7">
    <h3>Contenido del menú 7</h3> 
  </template>
  <template v-if="menu==8">
    <h3>Contenido del menú 8</h3> 
  </template>
  <template v-if="menu==9">
    <h3>Contenido del menú 9</h3> 
  </template>  

  <template v-if="menu==10">
    <h3>Contenido del menú 10</h3> 
  </template>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/dashboard/aplicacionesWeb/proyectosEnLaravel/proyecto_1/resources/views/principal/contenido.blade.php ENDPATH**/ ?>