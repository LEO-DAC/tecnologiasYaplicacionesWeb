# Plataforma para la administracion de proyectos y equipos de trabajo

## Descripcion del proyecto

Correo del profe en TeamGantt: damtec.dev@gmail.com

* Importante revisar proyecto base

Requirimientos grales: Sistema para free lancer

Requerimientos:
- Llevar control de dinero en base a los proyectos que se tiene
- Lista de proyectos
- Para cada proyecto puede o no meter equipos de trabajo
- Gestión de equipos de trabajo, e integrantes de equipo
- Gestion de clientes, proyectos, pagos de mi hacia colaboradores
- Administrador de tareas
- Gestión de empresas o contactos de empresas
- Gestión de tareas
- El project manager lleva el control de lo que le paga a cada quien, ellos no lo pueden ver solo pueden visualizar el pago final en base a las actividades que se le asignaron. En resumen cada tarea tiene un monto a pagar.
- Gestión de issues para cada proyecto. Estos los pueden ver desarrolladores y project manager. 
- Gestión de gastos, es como un listado de cada inversión que se aplica al proyecto. Tipos de costos
- Gestión de usuarios
- Gestión de recibos / tickets
- Gestión de configuración //que pedia




- Nota: Para cada desarrollador se hará una forma de acceder a proyectos y al acceder a este habrá una sección para ver las tareas estas son un checkbox y tiene fecha de vencimiento, todo se notifica al project manager.





- Usuarios:
	- Project manager, pueden ser varios y verlo todo pero no modificar datos que no registró cada quien
	- Desarrolladores
	- Clientes / Proveedores

Clientes:
	- Ver recibos de pagos
	- Hacer tickets
	- Ver tareas

Desarrolladores:
	- Responder tickets
	- Ver pagos
	- Ver tareas
	- Hacer issues

Atributos - proyecto:
	- Fecha de inicio
	- Fecha en que acaba
	- Status
	- id
	- tareas por proyecto
	- pagos, 
