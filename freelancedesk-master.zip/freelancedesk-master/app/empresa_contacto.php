<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class empresa_contacto extends Model
{
    //
}
