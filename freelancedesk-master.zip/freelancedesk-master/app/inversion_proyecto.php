<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class inversion_proyecto extends Model
{
    //
}
