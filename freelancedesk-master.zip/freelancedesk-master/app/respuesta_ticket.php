<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class respuesta_ticket extends Model
{
    //
}
