
            <div class="page-content d-flex align-items-stretch">
                <div class="default-sidebar">
                    <nav class="side-navbar box-scroll sidebar-scroll">
                        <ul class="list-unstyled">
														
                            <!--<li><a href="#"><i class="ion-hammer"></i><span>Mis tareas</span></a></li>
                            <li><a href="#"><i class="ion-cash"></i><span>Mis pagos</span></a></li>
                            <li><a href="#"><i class="ion-chatboxes"></i><span>Mis tickets</span></a></li> -->
														<li><router-link to="/abonos"> <i class="ion-chatboxes"></i>Mis Abonos</router-link></li>
													

                        </ul>
                    </nav>
                </div>
            </div>
        
