
<div class="page-content d-flex align-items-stretch">
    <div class="default-sidebar">
        <nav class="side-navbar box-scroll sidebar-scroll">
            <ul class="list-unstyled">
                <li><router-link to="/tareas"><i class="la la-thumb-tack"></i><span>Tareas</span></router-link></li>
                <li><router-link to="/pagos"><i class="fas fa-money-check-alt"></i><span>Pagos</span></router-link></li>
            </ul>
        </nav>
    </div>
</div>

