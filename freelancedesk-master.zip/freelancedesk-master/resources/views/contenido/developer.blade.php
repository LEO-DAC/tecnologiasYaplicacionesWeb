            <!-- End Header -->
            <!-- Begin Page Content -->
            <div class="page-content d-flex align-items-stretch">

                <!-- ################# -->
                <div class="default-sidebar">
                    <!-- Begin Side Navbar -->
                    <nav class="side-navbar box-scroll sidebar-scroll">
                        <!-- Begin Main Navigation -->
                        <ul class="list-unstyled">
												
                          <li><router-link to="/tareas"><i class="ion-hammer" style="color: #3490dc"></i><span>Mis tareas</span></a></router-link></li>
                            <li><router-link to="/pagos"><i class="ion-cash" style="color: #f6993f"></i><span>Pagos</span></a></router-link></li>
                        </ul>
                        <!-- End Main Navigation -->
                    </nav>
                    <!-- End Side Navbar -->
                </div>
                <!-- End Left Sidebar -->
             </div>
